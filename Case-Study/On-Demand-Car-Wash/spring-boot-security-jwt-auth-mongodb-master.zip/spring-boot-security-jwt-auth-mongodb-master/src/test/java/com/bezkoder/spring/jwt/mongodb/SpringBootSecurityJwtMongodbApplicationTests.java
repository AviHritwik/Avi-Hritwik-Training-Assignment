package com.bezkoder.spring.jwt.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJwtMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}

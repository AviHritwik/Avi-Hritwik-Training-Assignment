# Spring Boot, Spring Security, MongoDB - JWT Authentication & Authorization example

For more detail, please visit:
> [Spring Boot, MongoDB: JWT Authentication with Spring Security](https://bezkoder.com/spring-boot-jwt-auth-mongodb/)

Working with Front-end:
> [Vue.js JWT Authentication with Vuex and Vue Router](https://bezkoder.com/jwt-vue-vuex-authentication/)

> [Angular 8 JWT Authentication example](https://bezkoder.com/angular-jwt-authentication/)

> [Angular 10 JWT Authentication example](https://bezkoder.com/angular-10-jwt-auth/)

> [Angular 11 JWT Authentication example](https://bezkoder.com/angular-11-jwt-auth/)

> [React JWT Authentication & Authorization (without Redux) example](https://bezkoder.com/react-jwt-auth/)

> [React Redux JWT Authentication & Authorization example](https://bezkoder.com/react-redux-jwt-auth/)

Run both Back-end & Front-end in one place:
> [Integrate Angular with Spring Boot Rest API](https://bezkoder.com/integrate-angular-spring-boot/)

> [Integrate React.js with Spring Boot Rest API](https://bezkoder.com/integrate-reactjs-spring-boot/)

## Run Spring Boot application
```
mvn spring-boot:run
```

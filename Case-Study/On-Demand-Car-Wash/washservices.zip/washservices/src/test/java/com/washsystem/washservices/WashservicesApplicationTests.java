package com.washsystem.washservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WashservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}

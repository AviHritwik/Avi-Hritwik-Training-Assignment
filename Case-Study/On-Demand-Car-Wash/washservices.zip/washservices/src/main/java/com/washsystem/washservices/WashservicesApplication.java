package com.washsystem.washservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WashservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(WashservicesApplication.class, args);
	}

}
